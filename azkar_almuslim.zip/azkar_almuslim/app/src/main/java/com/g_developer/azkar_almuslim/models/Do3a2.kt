package com.g_developer.azkar_almuslim.models


data class Do3a2(private val id: Int,
                 private val name: String,
                 private val text: String,
                 private val mediaUrl: String)