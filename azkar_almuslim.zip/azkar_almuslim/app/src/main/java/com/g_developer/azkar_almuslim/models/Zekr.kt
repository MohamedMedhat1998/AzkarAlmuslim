package com.g_developer.azkar_almuslim.models

data class Zekr(private val id: Int,
                private val name: String,
                private val text: String,
                private val count: Int,
                private val mediaUrl: String)