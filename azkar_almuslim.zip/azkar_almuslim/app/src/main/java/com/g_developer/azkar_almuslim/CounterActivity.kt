package com.g_developer.azkar_almuslim

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.g_developer.azkar_almuslim.R

class CounterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_counter)
    }
}
