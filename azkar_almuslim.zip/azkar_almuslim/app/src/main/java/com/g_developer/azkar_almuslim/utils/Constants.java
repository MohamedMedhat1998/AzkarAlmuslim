package com.g_developer.azkar_almuslim.utils;

public class Constants {
    public static final String DATABASE_NAME = "Azkar.db";
}
