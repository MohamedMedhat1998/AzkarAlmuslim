package com.g_developer.azkar_almuslim.behaviors

interface CanOpenBrowser {
    fun openBrowser(link: String)
}